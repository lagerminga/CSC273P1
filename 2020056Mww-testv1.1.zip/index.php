
<!DOCTYPE html>
<html> 
<head>
<title>Page Title</title>
</head>
<body>


<?php

$servername = "aa116obigm3v0m.cfnlvfasi2n7.us-east-2.rds.amazonaws.com";
$username = "ddoms593";
$password = "12345678";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";


$sql = "SELECT * FROM Login.Data";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
       // echo "Username: " . $row["Username"]. " - Password: " . $row["Password"]. "<br>";
    }
} else {
    echo "0 results";
}

$_SESSION["username"] = $row["Username"];
$_SESSION["password"] = $row["Password"];



mysqli_close($conn);

?>



<h1>Welcome to the website</h1>
<img src="snake.jpg" alt="Snake with a hat"> <br>
<a href="page2.php">This link takes you to page 2</a>
    

<?php  
if ($_SESSION["username"]== $_POST["username"] && $_SESSION["password"] == $_POST["password"]){
	//echo ("Test");
	$_SESSION['Login'] = "True";
}


?>
	
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <input type="text" name="username" placeholder="Enter your username" required>
    <input type="password" name="password" placeholder="Enter your password" required>
    <input type="submit" value="Submit">
</form>




</body>
</html>















