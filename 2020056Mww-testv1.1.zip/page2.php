
<?php

session_start();

if ( isset( $_SESSION['login'] ) ) {
} else {
    header("Location: http://website1-env.2ixsanw3yd.us-east-2.elasticbeanstalk.com/index.php");
}
?>


<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>



<h1>Welcome to the secret page, congrats!</h1>
<p>This is where id put a paragraph..IF I HAD ONE!</p>

<a href="index.php">Return to main page</a>



<?php
session_unset();
session_destroy();
    
?>

</body>
</html>

